

import UIKit

class ViewController4: UIViewController{

    @IBOutlet weak var imgView: UIImageView!
    var image = UIImage()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imgView.image = image

     
    }
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
}
