

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var profileImageView: UIImageView!
    
    @IBOutlet weak var loginBtn: UIButton!
    @IBOutlet weak var passtxt: UITextField!
    @IBOutlet weak var usrnmtxt: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        profileImageView.layer.cornerRadius = profileImageView.frame.size.width / 2
        profileImageView.clipsToBounds = true
    }
   
    @IBAction func signUpBtn(_ sender: Any) {
        let Vc2 = self.storyboard?.instantiateViewController(withIdentifier: "ViewController2") as! ViewController2
        
        self.navigationController?.pushViewController(Vc2, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        self.navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
   
    
    func alert(titleMsg: String,message: String){
        let alert = UIAlertController(title: titleMsg, message: message, preferredStyle: .alert)
            
             let ok = UIAlertAction(title: "OK", style: .default, handler: { action in
             })
             alert.addAction(ok)
        
             DispatchQueue.main.async(execute: {
                self.present(alert, animated: true)
        })
    }
    @IBAction func btnPress(_ sender: Any) {
      
        validate()
    
    }
    
   func validate() {
    if usrnmtxt.text == "" {
        alert(titleMsg: "Alert", message: "Text Filed Name Should Not Be empty.")
        print("textField is empty")
        
    }else if passtxt.text == "" {
        alert(titleMsg: "Alert", message: "Password Should Not Be Empty")
        
        print("textField is empty")
        
        
    }else if passtxt.text!.count < 5 {
        alert(titleMsg: "Allert", message: "Password Must Be More Than 5 words")
        print("Password should be atleast 8 char or numbers")
        
    }else{
        let Vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController3") as! ViewController3
        
        Vc.UserNameee = usrnmtxt.text ?? ""
        
        self.navigationController?.pushViewController(Vc, animated: true)
        
    }
    
    
    
    
   
    

}

}
