

import UIKit

class ViewController3: UIViewController, UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "colorViewCell", for: indexPath) as! colorViewCell
    
        cell.textLbl.text = arrName[indexPath.row]
        cell.imgView?.image = UIImage(named: arrImg[ indexPath.row])
        
        return cell 
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let Vc2 = self.storyboard?.instantiateViewController(withIdentifier: "ViewController4") as! ViewController4
        Vc2.image = UIImage(named: arrImg[ indexPath.row])!
        self.navigationController?.pushViewController(Vc2, animated: true)
    }
    
  
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var userName: UILabel!
  var UserNameee = ""
    var arrName = ["blue", "green", "pink", "red", "yellow"]
    var arrImg = ["blue", "green", "pink", "red", "yellow"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
    

            userName.text = UserNameee
        tableView.delegate = self
        tableView.dataSource = self
       
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        self.navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    @IBAction func BackBtn(_ sender: Any) {
        self.dismiss(animated: true, completion: {});
        self.navigationController?.popViewController(animated: true);
    }

    
    
    
    
    

}
