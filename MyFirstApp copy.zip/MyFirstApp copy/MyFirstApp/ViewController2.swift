
import UIKit

class ViewController2: UIViewController {
    
    
    @IBOutlet weak var textNm: UITextField!
    
    @IBOutlet weak var textEmail: UITextField!
    
    @IBOutlet weak var textPhn: UITextField!
    
    @IBOutlet weak var textPass: UITextField!
  
    @IBOutlet weak var textConPass: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        self.navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    
    @IBAction func backBtn(_ sender: Any) {
        self.dismiss(animated: true, completion: {});
        self.navigationController?.popViewController(animated: true);
    }
    
    
    @IBAction func submitBtn(_ sender: Any) {
       validate()
    }
    
    func alert(titleMsg: String,message: String){
        let alert = UIAlertController(title: titleMsg, message: message, preferredStyle: .alert)
            
             let ok = UIAlertAction(title: "OK", style: .default, handler: { action in
             })
             alert.addAction(ok)
        
             DispatchQueue.main.async(execute: {
                self.present(alert, animated: true)
        })
    }
    func validate() {
     if textNm.text == "" {
         alert(titleMsg: "Alert", message: "Text Filed Name Should Not Be empty.")
         print("textField is empty")
         
     }else if textPhn.text == "" {
         alert(titleMsg: "Alert", message: "Text Field Password Should Not Be Empty.")
         
         print("textField is empty")
         
         
     }else if textEmail.text == "" {
         alert(titleMsg: "Allert", message: "Text Field  Email Should Not Be Empty.")
         print("Password should be atleast 8 char or numbers")
         
     }else if textPass.text == "" {
        alert(titleMsg: "Allert", message: "Password Should Not Be Empty")
        print("Password should be atleast 8 char or numbers")
     }
     //else if (textConPass.text! as NSObject) != textPass
        else if(textPass.text != self.textConPass.text){
           alert(titleMsg: "Allert", message: "Password Is Not Matched With Your Given Passowrd.")
           print("Password should be atleast 8 char or numbers")
     }
     
            else {
        self.dismiss(animated: true, completion: {});
        self.navigationController?.popViewController(animated: true);
         
     }
    
}
    
    }
